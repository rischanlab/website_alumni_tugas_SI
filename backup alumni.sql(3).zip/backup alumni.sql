-- phpMyAdmin SQL Dump
-- version 3.3.7deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 05, 2011 at 12:27 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `si_alumni`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_komentar`
--

CREATE TABLE IF NOT EXISTS `tbl_komentar` (
  `id_komentar` int(9) NOT NULL AUTO_INCREMENT,
  `id_user` int(9) NOT NULL,
  `id_teman` int(9) NOT NULL,
  `isi_komentar` text NOT NULL,
  `tanggal_komentar` date NOT NULL,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_komentar`
--

INSERT INTO `tbl_komentar` (`id_komentar`, `id_user`, `id_teman`, `isi_komentar`, `tanggal_komentar`) VALUES
(13, 3, 3, 'waah bagus sekali gambarnya :)', '2011-03-06'),
(14, 3, 7, 'kereen euuuy :)', '2011-03-06'),
(15, 7, 3, 'woow apa tuh?', '2011-03-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pertemanan`
--

CREATE TABLE IF NOT EXISTS `tbl_pertemanan` (
  `id_pertemanan` int(9) NOT NULL AUTO_INCREMENT,
  `id_user` int(9) NOT NULL,
  `id_teman` int(9) NOT NULL,
  `konfirmasi` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id_pertemanan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_pertemanan`
--

INSERT INTO `tbl_pertemanan` (`id_pertemanan`, `id_user`, `id_teman`, `konfirmasi`) VALUES
(30, 3, 4, 'yes'),
(31, 4, 6, 'yes'),
(32, 6, 3, 'yes'),
(33, 7, 3, 'yes'),
(34, 7, 4, 'yes'),
(35, 4, 8, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pesan`
--

CREATE TABLE IF NOT EXISTS `tbl_pesan` (
  `id_pesan` int(9) NOT NULL AUTO_INCREMENT,
  `id_user` int(9) NOT NULL,
  `id_teman` int(9) NOT NULL,
  `isi_pesan` text NOT NULL,
  `tanggal_pesan` date NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_pesan`
--

INSERT INTO `tbl_pesan` (`id_pesan`, `id_user`, `id_teman`, `isi_pesan`, `tanggal_pesan`) VALUES
(9, 3, 7, 'haloo agus. apa kabar?', '2011-03-06'),
(10, 7, 3, 'Assalamualikm dinda, alhamdulilah kabar baik. gimna kabar dinda senditi?', '2011-03-06'),
(11, 3, 7, 'syukurkah. alhamdulilah dinda juga baik kok ^_^', '2011-03-06'),
(12, 4, 7, 'duuhh...kangen siapa nech?? :p', '2011-03-06'),
(13, 7, 4, '', '2011-12-03'),
(14, 8, 8, 'jajal', '2011-12-03'),
(15, 7, 4, 'ihirrr', '2011-12-03'),
(16, 4, 8, 'makasig yah dag add', '2011-12-03'),
(17, 4, 8, 'ki..koq isane mung pesan yow..gwe comment status angel', '2011-12-05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE IF NOT EXISTS `tbl_photo` (
  `id_photo` int(9) NOT NULL AUTO_INCREMENT,
  `id_user` int(9) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `judul_photo` varchar(100) NOT NULL,
  `tanggal_photo` date NOT NULL,
  PRIMARY KEY (`id_photo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_photo`
--

INSERT INTO `tbl_photo` (`id_photo`, `id_user`, `photo`, `judul_photo`, `tanggal_photo`) VALUES
(2, 3, 'Picture 0001.jpg', 'kenangan', '2011-03-06'),
(3, 3, '895-21-02-2011.JPG', 'Statistik', '2011-03-06'),
(5, 3, '1.PNG', 'Test', '2011-03-06'),
(6, 3, '2.PNG', 'ada', '2011-03-06'),
(7, 7, '1.PNG', 'aku', '2011-03-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE IF NOT EXISTS `tbl_status` (
  `id_status` int(9) NOT NULL AUTO_INCREMENT,
  `id_user` int(9) NOT NULL,
  `isi_status` text NOT NULL,
  `tanggal_status` date NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`id_status`, `id_user`, `isi_status`, `tanggal_status`) VALUES
(46, 3, 'test', '2011-03-05'),
(47, 3, 'pegel', '2011-03-05'),
(48, 6, 'udah malem neh...', '2011-03-05'),
(49, 4, 'kangen', '2011-03-05'),
(51, 7, 'selamat pagi semuanya :)', '2011-03-06'),
(52, 8, 'coab', '2011-12-03'),
(53, 8, 'coaadad', '2011-12-03'),
(54, 4, 'cobababaaba', '2011-12-03'),
(55, 4, 'update status ahh', '2011-12-05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id_user` int(9) NOT NULL AUTO_INCREMENT,
  `nama_depan` varchar(50) NOT NULL,
  `nama_belakang` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `kelamin` enum('pria','wanita') NOT NULL,
  `nim` varchar(9) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `tgl_wisuda` date NOT NULL,
  `agama` enum('islam','katolik','protestan','hindu','budha') NOT NULL,
  `photo` varchar(100) NOT NULL,
  `status` enum('lajang','pacaran','menikah','lain-lain') NOT NULL,
  `alamat` text NOT NULL,
  `aktivitas` text NOT NULL,
  `posisi_skrg` varchar(30) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `hobi` text NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_depan`, `nama_belakang`, `email`, `password`, `kelamin`, `nim`, `tanggal_lahir`, `tgl_wisuda`, `agama`, `photo`, `status`, `alamat`, `aktivitas`, `posisi_skrg`, `latitude`, `longitude`, `hobi`) VALUES
(3, 'Suparmi Mangan ', 'Dimedjo', 'suparmi@yahoo.com', '202cb962ac59075b964b07152d234b70', 'wanita', '09650033', '1987-09-12', '2011-12-14', 'islam', 'suparmi.jpg', 'lajang', 'Jl. Salak VII No.140 Yogyakarta', 'Mengajar, kuliah', 'Yogyakarta', 0, 0, 'Programming'),
(4, 'Kiki', 'Paramidha', 'kiki@yahoo.com', '202cb962ac59075b964b07152d234b70', 'wanita', '09650006', '1987-12-15', '2011-12-13', 'islam', 'kiki.jpg', 'lajang', 'Jl. Magelang KM 30000', 'Kerja', 'Magelang', 0, 0, 'Bobo Ma kUcing'),
(6, 'Isnan', 'Kambing', 'isnan@yahoo.com', '202cb962ac59075b964b07152d234b70', 'pria', '09650014', '2011-03-01', '2011-12-28', 'islam', 'isnan.jpg', 'menikah', 'Jl. Walahar III Wates', 'Kerja di kantor camat', 'Wates', 0, 0, 'Pelihara kura-kura, buaya'),
(7, 'Mbahmu', 'Prawan', 'mbahmu@yahoo.com', '202cb962ac59075b964b07152d234b70', 'pria', '09651002', '1986-03-13', '2011-12-29', 'islam', 'mbahmu.jpg', 'pacaran', 'Jl. Cinta nO 3', 'Mengajar', 'Semarang', 0, 0, 'Membaca Hatimyu'),
(8, 'Rischan', 'Mafrur', 'riscahn@mafrur.com', '202cb962ac59075b964b07152d234b70', 'pria', '', '2011-12-05', '0000-00-00', 'islam', 'android.jpg', 'lajang', 'Prayan', 'Mahasiswa', '', 0, 0, 'coding'),
(9, 'Alfrizal', 'RaCheto', 'alfrizal@gmail.com', '202cb962ac59075b964b07152d234b70', 'wanita', '096500023', '1986-12-18', '2011-12-29', 'islam', 'alfrizal', 'lajang', 'Jl Jeruk Aceh', 'Maen Dota', 'Yogyakarta', 0, 0, 'Makan cript'),
(10, 'Haris', 'Solokhah', 'haris@yahoo.com', 'c0ba88b8bca79ca3b50b96abdf431766', 'pria', '09651000', '1987-12-16', '2011-12-21', 'islam', 'haris.jpg', 'lajang', 'Jln Kemana saja', 'Kuliah', 'Purworjo', 0, 0, 'Mancing Buaya');
